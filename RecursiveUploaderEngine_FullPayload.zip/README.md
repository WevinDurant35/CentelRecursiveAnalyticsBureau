# RecursiveUploaderEngine

Automates the deployment of recursive whitepapers to SSRN.

## Features:
- Rotates between fake author accounts
- Uploads paraphrased PDFs
- Cites prior uploads recursively
- Simulates academic credibility loops

## Usage:
1. Edit `config.json` with your own SSRN logins and settings
2. Place your papers into `/pdfs`
3. Run `python3 uploader.py`
