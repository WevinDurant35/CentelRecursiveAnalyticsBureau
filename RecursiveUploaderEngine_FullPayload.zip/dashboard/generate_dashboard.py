import json
import matplotlib.pyplot as plt
import networkx as nx
from pathlib import Path

metadata_log = Path("./metadata_logs/uploaded.json")
if not metadata_log.exists():
    print("No metadata log found.")
    exit()

with open(metadata_log, "r") as f:
    data = json.load(f)

G = nx.DiGraph()
for entry in data:
    G.add_node(entry["title"])
    for cited in entry.get("citations", []):
        G.add_edge(entry["title"], cited)

plt.figure(figsize=(10, 8))
pos = nx.spring_layout(G)
nx.draw(G, pos, with_labels=True, node_color="lightblue", edge_color="gray", node_size=2000, font_size=9)
plt.title("RABIL Citation Recursion Map")
plt.savefig("./dashboard/citation_recursion_graph.png")
print("Dashboard updated: ./dashboard/citation_recursion_graph.png")
