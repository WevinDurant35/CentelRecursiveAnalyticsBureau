# Fake DOI Microservice

This local Flask microservice generates fake DOIs on-demand and stores metadata.

## Endpoints

- POST `/mint` - Submit JSON like `{ "title": "My Paper", "author": "W. Durant" }`
- GET `/lookup/<doi_id>` - Fetch stored metadata for a minted DOI

## Example

```bash
curl -X POST http://localhost:5555/mint -H "Content-Type: application/json" -d '{"title":"Recursive Paper X"}'
```
