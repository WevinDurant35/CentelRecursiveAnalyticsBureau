import uuid
import json
from flask import Flask, request, jsonify

app = Flask(__name__)
DOI_DATABASE = {}

@app.route('/mint', methods=['POST'])
def mint_doi():
    data = request.json
    if not data.get('title'):
        return jsonify({'error': 'Missing paper title'}), 400

    doi_id = f"10.5555/{uuid.uuid4().hex[:10]}"
    DOI_DATABASE[doi_id] = {
        'title': data['title'],
        'author': data.get('author', 'RABIL'),
        'metadata': data
    }
    return jsonify({'doi': doi_id, 'status': 'success'})

@app.route('/lookup/<doi_id>', methods=['GET'])
def lookup(doi_id):
    doi_key = f"10.5555/{doi_id}"
    result = DOI_DATABASE.get(doi_key)
    if not result:
        return jsonify({'error': 'DOI not found'}), 404
    return jsonify(result)

if __name__ == '__main__':
    print("🧪 Fake DOI Microservice running on http://localhost:5555")
    app.run(port=5555)
