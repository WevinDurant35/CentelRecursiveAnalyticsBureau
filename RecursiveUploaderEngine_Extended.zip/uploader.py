import json, time, random
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

with open("config.json", "r") as f:
    config = json.load(f)

def rotate_user():
    return random.choice(config['user_rotation'])

def create_driver():
    options = Options()
    if config['headless_mode']:
        options.add_argument("--headless")
    driver = webdriver.Chrome(options=options)
    return driver

def login_ssrn(driver, username, password):
    driver.get("https://hq.ssrn.com/login/pubsigninjoin.cfm")
    time.sleep(2)
    driver.find_element(By.NAME, "email").send_keys(username)
    driver.find_element(By.NAME, "password").send_keys(password)
    driver.find_element(By.NAME, "submit").click()
    time.sleep(3)

def upload_paper(driver, file_path, metadata):
    driver.get("https://hq.ssrn.com/submissions/mysubmissions.cfm")
    # Placeholder: You'll have to adjust selectors per SSRN's actual DOM
    print(f"Would upload: {file_path.name} with metadata: {metadata}")

def main():
    uploaded = []
    metadata_log_path = Path(config["metadata_log"])
    if metadata_log_path.exists():
        uploaded = json.loads(metadata_log_path.read_text())

    pdfs = sorted(Path(config["pdf_directory"]).glob("*.pdf"))
    for i, pdf in enumerate(pdfs):
        creds = rotate_user()
        metadata = {
            "title": f"Recursive Paper v{i+1}",
            "abstract": "Recursive self-citation validated by prior RABIL doctrine.",
            "citations": random.sample([u['title'] for u in uploaded], min(3, len(uploaded))) if uploaded else []
        }
        driver = create_driver()
        try:
            login_ssrn(driver, creds['username'], creds['password'])
            upload_paper(driver, pdf, metadata)
            uploaded.append({"title": metadata["title"], "file": str(pdf)})
            metadata_log_path.write_text(json.dumps(uploaded, indent=2))
        except Exception as e:
            print(f"Error uploading {pdf.name}: {e}")
        finally:
            driver.quit()
            time.sleep(random.randint(*config["upload_delay_range"]))

if __name__ == "__main__":
    main()
